package com.auto.tasks.task2;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;

import static junit.framework.TestCase.assertTrue;

@DefaultUrl("http://www.way2automation.com/angularjs-protractor/webtables/")
public class TaskTwo extends PageObject {

    @Steps
    GlobalSteps globalSteps;

    @Test
    public void checkPageTitle(String expectedTitle) {
        assertTrue(getTitle().contains(expectedTitle));
    }

    @Test
    public void validateUserListTable(){
        globalSteps.validateTheTableList();
    }

    @Test
    public void clieckAddUserButton(){
        globalSteps.clickAddUser();
    }

    @Test
    public void addUser(){
        globalSteps.addUser("FName1","LName1","User1","Pass1","Company AAA","Admin"
        ,"admin@mail.com","082555");
    }
    @Test
    public void clieckAddUserButton2(){
        globalSteps.clickAddUser();
    }

    @Test
    public void addUser2(){
        globalSteps.addUser("FName2","LName2","User2","Pass2","Company BBB","Customer"
                ,"customer@mail.com","082444");
    }



}
