package com.auto.tasks.task2;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class GlobalSteps extends ScenarioSteps {

    private static final long serialVersionUID = 1L;

    @FindBy(css = "userTable")
    List<WebElement> tableList;

    @FindBy(css = "btnAddUser")
    WebElement clickAddUser;

    @FindBy(css = "FistName")
    WebElement fName;
    @FindBy(css = "lastName")
    WebElement lName;
    @FindBy(css = "userName")
    WebElement uName;
    @FindBy(css = "password")
    WebElement pass;
    @FindBy(css = "customer")
    WebElement customer;
    @FindBy(css = "role")
    WebElement role;
    @FindBy(css = "email")
    WebElement email;
    @FindBy(css = "cell")
    WebElement cell;

    @FindBy(css = "addButton")
    WebElement addButton;

    private TaskTwo basePage() {
        return getPages().currentPageAt(TaskTwo.class);
    }

    @Step
    public void checkPageTitle(String expectedTitle) {
        basePage().checkPageTitle(expectedTitle);
    }

    @Step List<String> validateTheTableList(){
        return tableList.stream().map(
                elment -> elment.getText())
                .collect(Collectors.toList());
    }

    @Step
    public void clickAddUser(){
        clickAddUser.click();
    }

    @Step
    public void addUser(String fName,String lName,String uName,String pass,String costomer,String role,
                        String email,String cell){
        this.fName.sendKeys(fName);
        this.lName.sendKeys(lName);this.uName.sendKeys(uName);this.pass.sendKeys(pass);
        this.customer.sendKeys(costomer);
        this.role.sendKeys(role);this.email.sendKeys(email);this.cell.sendKeys(cell);
        addButton.click();
    }




}
